# CultureHaystack results

Models: qwen3vl, qwen25vl, gemma4, gemma3_4b, granite4v, lfm25v


## acc_by_N

| model | mode | metric | N | acc | lo | hi | targets |
| --- | --- | --- | --- | --- | --- | --- | --- |
| gemma3_4b | mc | joint | 1 | 0.562 | 0.481 | 0.637 | 160 |
| gemma3_4b | mc | joint | 2 | 0.569 | 0.494 | 0.644 | 160 |
| gemma3_4b | mc | joint | 3 | 0.450 | 0.369 | 0.525 | 160 |
| gemma3_4b | mc | joint | 4 | 0.431 | 0.356 | 0.506 | 160 |
| gemma3_4b | mc | joint | 5 | 0.434 | 0.370 | 0.496 | 160 |
| gemma3_4b | mc | item | 1 | 0.744 | 0.675 | 0.806 | 160 |
| gemma3_4b | mc | item | 2 | 0.713 | 0.644 | 0.781 | 160 |
| gemma3_4b | mc | item | 3 | 0.662 | 0.588 | 0.738 | 160 |
| gemma3_4b | mc | item | 4 | 0.625 | 0.550 | 0.700 | 160 |
| gemma3_4b | mc | item | 5 | 0.600 | 0.536 | 0.662 | 160 |
| gemma3_4b | mc | country | 1 | 0.675 | 0.600 | 0.744 | 160 |
| gemma3_4b | mc | country | 2 | 0.731 | 0.656 | 0.800 | 160 |
| gemma3_4b | mc | country | 3 | 0.644 | 0.562 | 0.719 | 160 |
| gemma3_4b | mc | country | 4 | 0.644 | 0.569 | 0.719 | 160 |
| gemma3_4b | mc | country | 5 | 0.649 | 0.585 | 0.707 | 160 |
| gemma3_4b | open | joint | 1 | 0.150 | 0.094 | 0.206 | 160 |
| gemma3_4b | open | joint | 2 | 0.188 | 0.131 | 0.250 | 160 |
| gemma3_4b | open | joint | 3 | 0.188 | 0.131 | 0.250 | 160 |
| gemma3_4b | open | joint | 4 | 0.181 | 0.125 | 0.237 | 160 |
| gemma3_4b | open | joint | 5 | 0.166 | 0.116 | 0.219 | 160 |
| gemma3_4b | open | item | 1 | 0.188 | 0.131 | 0.244 | 160 |
| gemma3_4b | open | item | 2 | 0.219 | 0.156 | 0.281 | 160 |
| gemma3_4b | open | item | 3 | 0.212 | 0.150 | 0.275 | 160 |
| gemma3_4b | open | item | 4 | 0.225 | 0.163 | 0.287 | 160 |
| gemma3_4b | open | item | 5 | 0.199 | 0.145 | 0.255 | 160 |
| gemma3_4b | open | country | 1 | 0.463 | 0.388 | 0.537 | 160 |
| gemma3_4b | open | country | 2 | 0.494 | 0.419 | 0.569 | 160 |
| gemma3_4b | open | country | 3 | 0.481 | 0.406 | 0.556 | 160 |
| gemma3_4b | open | country | 4 | 0.431 | 0.356 | 0.506 | 160 |
| gemma3_4b | open | country | 5 | 0.436 | 0.366 | 0.507 | 160 |
| gemma4 | mc | joint | 1 | 0.856 | 0.800 | 0.906 | 160 |
| gemma4 | mc | joint | 2 | 0.825 | 0.762 | 0.887 | 160 |
| gemma4 | mc | joint | 3 | 0.819 | 0.756 | 0.881 | 160 |
| gemma4 | mc | joint | 4 | 0.831 | 0.769 | 0.887 | 160 |
| gemma4 | mc | joint | 5 | 0.801 | 0.745 | 0.855 | 160 |
| gemma4 | mc | item | 1 | 0.912 | 0.863 | 0.950 | 160 |
| gemma4 | mc | item | 2 | 0.875 | 0.819 | 0.925 | 160 |
| gemma4 | mc | item | 3 | 0.856 | 0.800 | 0.906 | 160 |
| gemma4 | mc | item | 4 | 0.881 | 0.825 | 0.931 | 160 |
| gemma4 | mc | item | 5 | 0.868 | 0.818 | 0.912 | 160 |
| gemma4 | mc | country | 1 | 0.881 | 0.825 | 0.925 | 160 |
| gemma4 | mc | country | 2 | 0.863 | 0.806 | 0.912 | 160 |
| gemma4 | mc | country | 3 | 0.844 | 0.787 | 0.894 | 160 |
| gemma4 | mc | country | 4 | 0.844 | 0.787 | 0.900 | 160 |
| gemma4 | mc | country | 5 | 0.821 | 0.767 | 0.870 | 160 |
| gemma4 | open | joint | 1 | 0.181 | 0.125 | 0.244 | 160 |
| gemma4 | open | joint | 2 | 0.156 | 0.106 | 0.212 | 160 |
| gemma4 | open | joint | 3 | 0.169 | 0.113 | 0.225 | 160 |
| gemma4 | open | joint | 4 | 0.163 | 0.106 | 0.219 | 160 |
| gemma4 | open | joint | 5 | 0.160 | 0.109 | 0.215 | 160 |
| gemma4 | open | item | 1 | 0.237 | 0.175 | 0.306 | 160 |
| gemma4 | open | item | 2 | 0.194 | 0.138 | 0.256 | 160 |
| gemma4 | open | item | 3 | 0.212 | 0.150 | 0.275 | 160 |
| gemma4 | open | item | 4 | 0.188 | 0.131 | 0.244 | 160 |
| gemma4 | open | item | 5 | 0.214 | 0.159 | 0.273 | 160 |
| gemma4 | open | country | 1 | 0.381 | 0.312 | 0.456 | 160 |
| gemma4 | open | country | 2 | 0.338 | 0.269 | 0.412 | 160 |
| gemma4 | open | country | 3 | 0.362 | 0.287 | 0.438 | 160 |
| gemma4 | open | country | 4 | 0.350 | 0.281 | 0.419 | 160 |
| gemma4 | open | country | 5 | 0.349 | 0.280 | 0.420 | 160 |
| granite4v | mc | joint | 1 | 0.544 | 0.469 | 0.619 | 160 |
| granite4v | mc | joint | 2 | 0.494 | 0.419 | 0.569 | 160 |
| granite4v | mc | joint | 3 | 0.381 | 0.306 | 0.456 | 160 |
| granite4v | mc | joint | 4 | 0.319 | 0.250 | 0.388 | 160 |
| granite4v | mc | joint | 5 | 0.320 | 0.260 | 0.381 | 160 |
| granite4v | mc | item | 1 | 0.681 | 0.613 | 0.750 | 160 |
| granite4v | mc | item | 2 | 0.662 | 0.594 | 0.731 | 160 |
| granite4v | mc | item | 3 | 0.575 | 0.500 | 0.650 | 160 |
| granite4v | mc | item | 4 | 0.562 | 0.487 | 0.637 | 160 |
| granite4v | mc | item | 5 | 0.556 | 0.489 | 0.623 | 160 |
| granite4v | mc | country | 1 | 0.656 | 0.581 | 0.731 | 160 |
| granite4v | mc | country | 2 | 0.594 | 0.519 | 0.662 | 160 |
| granite4v | mc | country | 3 | 0.494 | 0.419 | 0.569 | 160 |
| granite4v | mc | country | 4 | 0.469 | 0.388 | 0.550 | 160 |
| granite4v | mc | country | 5 | 0.426 | 0.363 | 0.494 | 160 |
| granite4v | open | joint | 1 | 0.044 | 0.013 | 0.075 | 160 |
| granite4v | open | joint | 2 | 0.069 | 0.031 | 0.113 | 160 |
| granite4v | open | joint | 3 | 0.050 | 0.019 | 0.081 | 160 |
| granite4v | open | joint | 4 | 0.056 | 0.025 | 0.094 | 160 |
| granite4v | open | joint | 5 | 0.064 | 0.030 | 0.100 | 160 |
| granite4v | open | item | 1 | 0.087 | 0.044 | 0.138 | 160 |
| granite4v | open | item | 2 | 0.119 | 0.069 | 0.169 | 160 |
| granite4v | open | item | 3 | 0.100 | 0.056 | 0.150 | 160 |
| granite4v | open | item | 4 | 0.113 | 0.069 | 0.163 | 160 |
| granite4v | open | item | 5 | 0.113 | 0.070 | 0.160 | 160 |
| granite4v | open | country | 1 | 0.219 | 0.156 | 0.281 | 160 |
| granite4v | open | country | 2 | 0.169 | 0.113 | 0.225 | 160 |
| granite4v | open | country | 3 | 0.175 | 0.119 | 0.237 | 160 |
| granite4v | open | country | 4 | 0.169 | 0.113 | 0.225 | 160 |
| granite4v | open | country | 5 | 0.179 | 0.127 | 0.235 | 160 |
| lfm25v | mc | joint | 1 | 0.556 | 0.481 | 0.631 | 160 |
| lfm25v | mc | joint | 2 | 0.494 | 0.419 | 0.569 | 160 |
| lfm25v | mc | joint | 3 | 0.381 | 0.306 | 0.456 | 160 |
| lfm25v | mc | joint | 4 | 0.344 | 0.275 | 0.419 | 160 |
| lfm25v | mc | joint | 5 | 0.315 | 0.256 | 0.376 | 160 |
| lfm25v | mc | item | 1 | 0.731 | 0.669 | 0.800 | 160 |
| lfm25v | mc | item | 2 | 0.688 | 0.619 | 0.756 | 160 |
| lfm25v | mc | item | 3 | 0.644 | 0.569 | 0.713 | 160 |
| lfm25v | mc | item | 4 | 0.600 | 0.525 | 0.675 | 160 |
| lfm25v | mc | item | 5 | 0.571 | 0.506 | 0.635 | 160 |
| lfm25v | mc | country | 1 | 0.694 | 0.619 | 0.762 | 160 |
| lfm25v | mc | country | 2 | 0.631 | 0.556 | 0.706 | 160 |
| lfm25v | mc | country | 3 | 0.525 | 0.444 | 0.600 | 160 |
| lfm25v | mc | country | 4 | 0.506 | 0.431 | 0.581 | 160 |
| lfm25v | mc | country | 5 | 0.450 | 0.385 | 0.516 | 160 |
| lfm25v | open | joint | 1 | 0.131 | 0.081 | 0.188 | 160 |
| lfm25v | open | joint | 2 | 0.106 | 0.062 | 0.156 | 160 |
| lfm25v | open | joint | 3 | 0.131 | 0.081 | 0.188 | 160 |
| lfm25v | open | joint | 4 | 0.113 | 0.069 | 0.163 | 160 |
| lfm25v | open | joint | 5 | 0.101 | 0.060 | 0.144 | 160 |
| lfm25v | open | item | 1 | 0.194 | 0.131 | 0.256 | 160 |
| lfm25v | open | item | 2 | 0.181 | 0.125 | 0.244 | 160 |
| lfm25v | open | item | 3 | 0.194 | 0.138 | 0.256 | 160 |
| lfm25v | open | item | 4 | 0.206 | 0.144 | 0.275 | 160 |
| lfm25v | open | item | 5 | 0.184 | 0.134 | 0.241 | 160 |
| lfm25v | open | country | 1 | 0.356 | 0.287 | 0.431 | 160 |
| lfm25v | open | country | 2 | 0.356 | 0.287 | 0.431 | 160 |
| lfm25v | open | country | 3 | 0.350 | 0.281 | 0.425 | 160 |
| lfm25v | open | country | 4 | 0.350 | 0.281 | 0.425 | 160 |
| lfm25v | open | country | 5 | 0.319 | 0.255 | 0.385 | 160 |
| qwen25vl | mc | joint | 1 | 0.694 | 0.625 | 0.762 | 160 |
| qwen25vl | mc | joint | 2 | 0.744 | 0.681 | 0.806 | 160 |
| qwen25vl | mc | joint | 3 | 0.738 | 0.675 | 0.806 | 160 |
| qwen25vl | mc | joint | 4 | 0.750 | 0.688 | 0.812 | 160 |
| qwen25vl | mc | joint | 5 | 0.753 | 0.694 | 0.812 | 160 |
| qwen25vl | mc | item | 1 | 0.844 | 0.787 | 0.900 | 160 |
| qwen25vl | mc | item | 2 | 0.900 | 0.856 | 0.944 | 160 |
| qwen25vl | mc | item | 3 | 0.900 | 0.850 | 0.944 | 160 |
| qwen25vl | mc | item | 4 | 0.906 | 0.856 | 0.950 | 160 |
| qwen25vl | mc | item | 5 | 0.911 | 0.870 | 0.946 | 160 |
| qwen25vl | mc | country | 1 | 0.756 | 0.688 | 0.825 | 160 |
| qwen25vl | mc | country | 2 | 0.781 | 0.719 | 0.844 | 160 |
| qwen25vl | mc | country | 3 | 0.787 | 0.725 | 0.850 | 160 |
| qwen25vl | mc | country | 4 | 0.800 | 0.738 | 0.856 | 160 |
| qwen25vl | mc | country | 5 | 0.792 | 0.735 | 0.848 | 160 |
| qwen25vl | open | joint | 1 | 0.300 | 0.231 | 0.369 | 160 |
| qwen25vl | open | joint | 2 | 0.306 | 0.237 | 0.381 | 160 |
| qwen25vl | open | joint | 3 | 0.294 | 0.225 | 0.362 | 160 |
| qwen25vl | open | joint | 4 | 0.281 | 0.212 | 0.350 | 160 |
| qwen25vl | open | joint | 5 | 0.285 | 0.219 | 0.352 | 160 |
| qwen25vl | open | item | 1 | 0.369 | 0.294 | 0.444 | 160 |
| qwen25vl | open | item | 2 | 0.375 | 0.306 | 0.450 | 160 |
| qwen25vl | open | item | 3 | 0.369 | 0.294 | 0.444 | 160 |
| qwen25vl | open | item | 4 | 0.344 | 0.269 | 0.419 | 160 |
| qwen25vl | open | item | 5 | 0.362 | 0.290 | 0.438 | 160 |
| qwen25vl | open | country | 1 | 0.431 | 0.356 | 0.506 | 160 |
| qwen25vl | open | country | 2 | 0.431 | 0.356 | 0.506 | 160 |
| qwen25vl | open | country | 3 | 0.431 | 0.356 | 0.506 | 160 |
| qwen25vl | open | country | 4 | 0.419 | 0.344 | 0.494 | 160 |
| qwen25vl | open | country | 5 | 0.419 | 0.346 | 0.490 | 160 |
| qwen3vl | mc | joint | 1 | 0.831 | 0.769 | 0.887 | 160 |
| qwen3vl | mc | joint | 2 | 0.806 | 0.744 | 0.863 | 160 |
| qwen3vl | mc | joint | 3 | 0.787 | 0.719 | 0.850 | 160 |
| qwen3vl | mc | joint | 4 | 0.775 | 0.713 | 0.838 | 160 |
| qwen3vl | mc | joint | 5 | 0.807 | 0.750 | 0.861 | 160 |
| qwen3vl | mc | item | 1 | 0.863 | 0.806 | 0.912 | 160 |
| qwen3vl | mc | item | 2 | 0.869 | 0.812 | 0.919 | 160 |
| qwen3vl | mc | item | 3 | 0.838 | 0.775 | 0.894 | 160 |
| qwen3vl | mc | item | 4 | 0.825 | 0.762 | 0.881 | 160 |
| qwen3vl | mc | item | 5 | 0.879 | 0.835 | 0.917 | 160 |
| qwen3vl | mc | country | 1 | 0.881 | 0.825 | 0.925 | 160 |
| qwen3vl | mc | country | 2 | 0.844 | 0.787 | 0.894 | 160 |
| qwen3vl | mc | country | 3 | 0.850 | 0.794 | 0.906 | 160 |
| qwen3vl | mc | country | 4 | 0.825 | 0.762 | 0.881 | 160 |
| qwen3vl | mc | country | 5 | 0.845 | 0.794 | 0.892 | 160 |
| qwen3vl | open | joint | 1 | 0.188 | 0.131 | 0.250 | 160 |
| qwen3vl | open | joint | 2 | 0.194 | 0.138 | 0.256 | 160 |
| qwen3vl | open | joint | 3 | 0.194 | 0.131 | 0.256 | 160 |
| qwen3vl | open | joint | 4 | 0.175 | 0.113 | 0.231 | 160 |
| qwen3vl | open | joint | 5 | 0.190 | 0.135 | 0.248 | 160 |
| qwen3vl | open | item | 1 | 0.269 | 0.200 | 0.338 | 160 |
| qwen3vl | open | item | 2 | 0.237 | 0.175 | 0.300 | 160 |
| qwen3vl | open | item | 3 | 0.256 | 0.188 | 0.319 | 160 |
| qwen3vl | open | item | 4 | 0.231 | 0.169 | 0.294 | 160 |
| qwen3vl | open | item | 5 | 0.237 | 0.180 | 0.296 | 160 |
| qwen3vl | open | country | 1 | 0.463 | 0.388 | 0.544 | 160 |
| qwen3vl | open | country | 2 | 0.475 | 0.400 | 0.550 | 160 |
| qwen3vl | open | country | 3 | 0.481 | 0.406 | 0.556 | 160 |
| qwen3vl | open | country | 4 | 0.469 | 0.394 | 0.544 | 160 |
| qwen3vl | open | country | 5 | 0.470 | 0.396 | 0.540 | 160 |


## scaling_summary

| model | mode | acc_N1 | initial_drop | drop_lo | drop_hi | slope_per_image | slope_lo | slope_hi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| gemma3_4b | mc | 0.562 | -0.006 | -0.069 | 0.056 | -0.042 | -0.062 | -0.024 |
| gemma3_4b | open | 0.150 | -0.038 | -0.075 | -0.006 | -0.007 | -0.018 | 0.004 |
| gemma4 | mc | 0.856 | 0.031 | 0.000 | 0.069 | -0.006 | -0.020 | 0.007 |
| gemma4 | open | 0.181 | 0.025 | 0.006 | 0.050 | 0.001 | -0.005 | 0.006 |
| granite4v | mc | 0.544 | 0.050 | -0.006 | 0.106 | -0.058 | -0.078 | -0.040 |
| granite4v | open | 0.044 | -0.025 | -0.056 | 0.000 | -0.001 | -0.008 | 0.005 |
| lfm25v | mc | 0.556 | 0.062 | 0.006 | 0.119 | -0.057 | -0.078 | -0.038 |
| lfm25v | open | 0.131 | 0.025 | 0.000 | 0.056 | -0.003 | -0.010 | 0.004 |
| qwen25vl | mc | 0.694 | -0.050 | -0.100 | -0.006 | 0.004 | -0.006 | 0.013 |
| qwen25vl | open | 0.300 | -0.006 | -0.025 | 0.013 | -0.008 | -0.017 | 0.001 |
| qwen3vl | mc | 0.831 | 0.025 | -0.012 | 0.069 | -0.001 | -0.015 | 0.013 |
| qwen3vl | open | 0.188 | -0.006 | -0.044 | 0.031 | -0.003 | -0.013 | 0.006 |


## h1_scaling_fit

| model | mode | aic_linear | aic_step | aic_step_plus_linear | lr_p_step_given_linear | step_coef | linear_coef_alone | linear_p_clustered | lr_p_holm | verdict |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| gemma3_4b | mc | 1103.069 | 1108.503 | 1105.028 | 0.840 | 0.051 | -0.156 | 0.000 | 1.000 | H1 rejected (gradual) |
| gemma3_4b | open | 748.844 | 748.075 | 749.973 | 0.351 | 0.310 | 0.030 | 0.306 | 1.000 | inconclusive or no decline |
| gemma4 | mc | 738.739 | 738.525 | 740.421 | 0.573 | -0.191 | -0.066 | 0.110 | 1.000 | inconclusive or no decline |
| gemma4 | open | 727.000 | 726.773 | 728.716 | 0.594 | -0.178 | -0.013 | 0.580 | 1.000 | inconclusive or no decline |
| granite4v | mc | 1059.818 | 1072.396 | 1061.797 | 0.885 | -0.037 | -0.269 | 0.000 | 1.000 | H1 rejected (gradual) |
| granite4v | open | 366.037 | 366.142 | 367.886 | 0.698 | 0.217 | 0.111 | 0.070 | 1.000 | inconclusive or no decline |
| lfm25v | mc | 1060.560 | 1073.584 | 1062.499 | 0.806 | -0.062 | -0.279 | 0.000 | 1.000 | H1 rejected (gradual) |
| lfm25v | open | 569.806 | 570.266 | 571.804 | 0.964 | -0.017 | -0.081 | 0.022 | 1.000 | H1 rejected (gradual) |
| qwen25vl | mc | 923.340 | 923.119 | 924.919 | 0.516 | 0.182 | 0.074 | 0.022 | 1.000 | inconclusive or no decline |
| qwen25vl | open | 972.568 | 972.723 | 974.540 | 0.868 | 0.045 | -0.024 | 0.128 | 1.000 | inconclusive or no decline |
| qwen3vl | mc | 806.284 | 806.051 | 807.930 | 0.552 | -0.190 | -0.066 | 0.091 | 1.000 | inconclusive or no decline |
| qwen3vl | open | 776.087 | 776.124 | 778.050 | 0.848 | 0.061 | -0.012 | 0.592 | 1.000 | inconclusive or no decline |


## position_profile

| model | mode | slot | acc | lo | hi |
| --- | --- | --- | --- | --- | --- |
| gemma3_4b | mc | 1 | 0.481 | 0.406 | 0.556 |
| gemma3_4b | mc | 2 | 0.356 | 0.281 | 0.431 |
| gemma3_4b | mc | 3 | 0.381 | 0.306 | 0.456 |
| gemma3_4b | mc | 4 | 0.419 | 0.344 | 0.494 |
| gemma3_4b | mc | 5 | 0.531 | 0.456 | 0.606 |
| gemma3_4b | open | 1 | 0.175 | 0.119 | 0.237 |
| gemma3_4b | open | 2 | 0.144 | 0.094 | 0.200 |
| gemma3_4b | open | 3 | 0.156 | 0.100 | 0.212 |
| gemma3_4b | open | 4 | 0.181 | 0.125 | 0.237 |
| gemma3_4b | open | 5 | 0.175 | 0.119 | 0.231 |
| gemma4 | mc | 1 | 0.838 | 0.781 | 0.887 |
| gemma4 | mc | 2 | 0.800 | 0.738 | 0.856 |
| gemma4 | mc | 3 | 0.800 | 0.738 | 0.863 |
| gemma4 | mc | 4 | 0.781 | 0.713 | 0.844 |
| gemma4 | mc | 5 | 0.787 | 0.725 | 0.850 |
| gemma4 | open | 1 | 0.169 | 0.113 | 0.231 |
| gemma4 | open | 2 | 0.169 | 0.113 | 0.231 |
| gemma4 | open | 3 | 0.144 | 0.094 | 0.200 |
| gemma4 | open | 4 | 0.169 | 0.113 | 0.231 |
| gemma4 | open | 5 | 0.150 | 0.100 | 0.206 |
| granite4v | mc | 1 | 0.400 | 0.325 | 0.475 |
| granite4v | mc | 2 | 0.269 | 0.200 | 0.338 |
| granite4v | mc | 3 | 0.275 | 0.206 | 0.350 |
| granite4v | mc | 4 | 0.312 | 0.237 | 0.388 |
| granite4v | mc | 5 | 0.344 | 0.269 | 0.419 |
| granite4v | open | 1 | 0.056 | 0.025 | 0.094 |
| granite4v | open | 2 | 0.069 | 0.031 | 0.113 |
| granite4v | open | 3 | 0.069 | 0.031 | 0.113 |
| granite4v | open | 4 | 0.056 | 0.025 | 0.094 |
| granite4v | open | 5 | 0.069 | 0.031 | 0.113 |
| lfm25v | mc | 1 | 0.381 | 0.306 | 0.456 |
| lfm25v | mc | 2 | 0.300 | 0.231 | 0.369 |
| lfm25v | mc | 3 | 0.231 | 0.169 | 0.294 |
| lfm25v | mc | 4 | 0.287 | 0.219 | 0.356 |
| lfm25v | mc | 5 | 0.375 | 0.306 | 0.450 |
| lfm25v | open | 1 | 0.106 | 0.062 | 0.156 |
| lfm25v | open | 2 | 0.087 | 0.044 | 0.131 |
| lfm25v | open | 3 | 0.087 | 0.044 | 0.131 |
| lfm25v | open | 4 | 0.113 | 0.062 | 0.163 |
| lfm25v | open | 5 | 0.113 | 0.062 | 0.163 |
| qwen25vl | mc | 1 | 0.781 | 0.719 | 0.844 |
| qwen25vl | mc | 2 | 0.744 | 0.675 | 0.806 |
| qwen25vl | mc | 3 | 0.744 | 0.675 | 0.812 |
| qwen25vl | mc | 4 | 0.750 | 0.681 | 0.819 |
| qwen25vl | mc | 5 | 0.744 | 0.675 | 0.812 |
| qwen25vl | open | 1 | 0.294 | 0.225 | 0.369 |
| qwen25vl | open | 2 | 0.281 | 0.212 | 0.350 |
| qwen25vl | open | 3 | 0.287 | 0.219 | 0.356 |
| qwen25vl | open | 4 | 0.275 | 0.206 | 0.344 |
| qwen25vl | open | 5 | 0.287 | 0.219 | 0.356 |
| qwen3vl | mc | 1 | 0.838 | 0.775 | 0.894 |
| qwen3vl | mc | 2 | 0.794 | 0.731 | 0.856 |
| qwen3vl | mc | 3 | 0.812 | 0.750 | 0.869 |
| qwen3vl | mc | 4 | 0.787 | 0.725 | 0.850 |
| qwen3vl | mc | 5 | 0.806 | 0.744 | 0.869 |
| qwen3vl | open | 1 | 0.188 | 0.131 | 0.250 |
| qwen3vl | open | 2 | 0.188 | 0.131 | 0.250 |
| qwen3vl | open | 3 | 0.206 | 0.144 | 0.269 |
| qwen3vl | open | 4 | 0.188 | 0.131 | 0.250 |
| qwen3vl | open | 5 | 0.181 | 0.125 | 0.244 |


## h2_position

| model | mode | position_gap | gap_lo | gap_hi | quad_coef | quad_p | quad_p_holm | verdict |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| gemma3_4b | mc | 0.175 | 0.112 | 0.250 | 0.142 | 0.000 | 0.000 | H2 supported (U-shape) |
| gemma3_4b | open | 0.038 | 0.019 | 0.081 | 0.032 | 0.247 | 1.000 | H2 not supported |
| gemma4 | mc | 0.056 | 0.025 | 0.100 | 0.033 | 0.219 | 1.000 | H2 not supported |
| gemma4 | open | 0.025 | 0.012 | 0.062 | 0.006 | 0.665 | 1.000 | H2 not supported |
| granite4v | mc | 0.131 | 0.075 | 0.206 | 0.116 | 0.001 | 0.008 | H2 supported (U-shape) |
| granite4v | open | 0.013 | 0.006 | 0.050 | -0.015 | 0.714 | 1.000 | H2 not supported |
| lfm25v | mc | 0.150 | 0.106 | 0.219 | 0.153 | 0.000 | 0.000 | H2 supported (U-shape) |
| lfm25v | open | 0.025 | 0.012 | 0.075 | 0.048 | 0.085 | 0.763 | H2 not supported |
| qwen25vl | mc | 0.037 | 0.025 | 0.094 | 0.027 | 0.322 | 1.000 | H2 not supported |
| qwen25vl | open | 0.019 | 0.012 | 0.056 | 0.011 | 0.494 | 1.000 | H2 not supported |
| qwen3vl | mc | 0.050 | 0.025 | 0.100 | 0.038 | 0.217 | 1.000 | H2 not supported |
| qwen3vl | open | 0.025 | 0.012 | 0.063 | -0.023 | 0.362 | 1.000 | H2 not supported |


## error_shares_by_N

| model | mode | N | wrong_fields | mis_binding | prior_drift | abstain | format_error |
| --- | --- | --- | --- | --- | --- | --- | --- |
| gemma3_4b | mc | 2 | 89 | 0.236 | 0.764 | 0.000 | 0.000 |
| gemma3_4b | mc | 3 | 111 | 0.523 | 0.477 | 0.000 | 0.000 |
| gemma3_4b | mc | 4 | 117 | 0.744 | 0.256 | 0.000 | 0.000 |
| gemma3_4b | mc | 5 | 601 | 0.998 | 0.000 | 0.000 | 0.002 |
| gemma3_4b | open | 2 | 206 | 0.010 | 0.956 | 0.034 | 0.000 |
| gemma3_4b | open | 3 | 209 | 0.014 | 0.962 | 0.024 | 0.000 |
| gemma3_4b | open | 4 | 215 | 0.037 | 0.907 | 0.056 | 0.000 |
| gemma3_4b | open | 5 | 1092 | 0.057 | 0.888 | 0.055 | 0.000 |
| gemma4 | mc | 2 | 42 | 0.190 | 0.810 | 0.000 | 0.000 |
| gemma4 | mc | 3 | 48 | 0.521 | 0.479 | 0.000 | 0.000 |
| gemma4 | mc | 4 | 44 | 0.636 | 0.364 | 0.000 | 0.000 |
| gemma4 | mc | 5 | 249 | 1.000 | 0.000 | 0.000 | 0.000 |
| gemma4 | open | 2 | 235 | 0.009 | 0.723 | 0.268 | 0.000 |
| gemma4 | open | 3 | 228 | 0.018 | 0.724 | 0.259 | 0.000 |
| gemma4 | open | 4 | 234 | 0.026 | 0.718 | 0.256 | 0.000 |
| gemma4 | open | 5 | 1150 | 0.037 | 0.713 | 0.250 | 0.000 |
| granite4v | mc | 2 | 119 | 0.277 | 0.639 | 0.000 | 0.084 |
| granite4v | mc | 3 | 149 | 0.564 | 0.349 | 0.000 | 0.087 |
| granite4v | mc | 4 | 155 | 0.716 | 0.194 | 0.000 | 0.090 |
| granite4v | mc | 5 | 814 | 0.918 | 0.000 | 0.000 | 0.082 |
| granite4v | open | 2 | 274 | 0.000 | 0.569 | 0.431 | 0.000 |
| granite4v | open | 3 | 276 | 0.007 | 0.583 | 0.409 | 0.000 |
| granite4v | open | 4 | 275 | 0.015 | 0.556 | 0.429 | 0.000 |
| granite4v | open | 5 | 1367 | 0.029 | 0.568 | 0.404 | 0.000 |
| lfm25v | mc | 2 | 109 | 0.431 | 0.569 | 0.000 | 0.000 |
| lfm25v | mc | 3 | 133 | 0.639 | 0.361 | 0.000 | 0.000 |
| lfm25v | mc | 4 | 143 | 0.839 | 0.161 | 0.000 | 0.000 |
| lfm25v | mc | 5 | 783 | 1.000 | 0.000 | 0.000 | 0.000 |
| lfm25v | open | 2 | 234 | 0.009 | 0.675 | 0.316 | 0.000 |
| lfm25v | open | 3 | 233 | 0.004 | 0.670 | 0.326 | 0.000 |
| lfm25v | open | 4 | 231 | 0.013 | 0.671 | 0.316 | 0.000 |
| lfm25v | open | 5 | 1198 | 0.018 | 0.654 | 0.329 | 0.000 |
| qwen25vl | mc | 2 | 51 | 0.176 | 0.824 | 0.000 | 0.000 |
| qwen25vl | mc | 3 | 50 | 0.460 | 0.540 | 0.000 | 0.000 |
| qwen25vl | mc | 4 | 47 | 0.617 | 0.383 | 0.000 | 0.000 |
| qwen25vl | mc | 5 | 237 | 1.000 | 0.000 | 0.000 | 0.000 |
| qwen25vl | open | 2 | 191 | 0.005 | 0.686 | 0.309 | 0.000 |
| qwen25vl | open | 3 | 192 | 0.005 | 0.677 | 0.318 | 0.000 |
| qwen25vl | open | 4 | 198 | 0.005 | 0.646 | 0.348 | 0.000 |
| qwen25vl | open | 5 | 975 | 0.017 | 0.667 | 0.316 | 0.000 |
| qwen3vl | mc | 2 | 46 | 0.217 | 0.783 | 0.000 | 0.000 |
| qwen3vl | mc | 3 | 50 | 0.520 | 0.480 | 0.000 | 0.000 |
| qwen3vl | mc | 4 | 56 | 0.696 | 0.304 | 0.000 | 0.000 |
| qwen3vl | mc | 5 | 221 | 1.000 | 0.000 | 0.000 | 0.000 |
| qwen3vl | open | 2 | 206 | 0.005 | 0.845 | 0.150 | 0.000 |
| qwen3vl | open | 3 | 202 | 0.020 | 0.876 | 0.104 | 0.000 |
| qwen3vl | open | 4 | 208 | 0.029 | 0.856 | 0.115 | 0.000 |
| qwen3vl | open | 5 | 1034 | 0.044 | 0.833 | 0.123 | 0.000 |


## h3a_context_attraction

| model | mode | N | wrong_naming_an_image | share_shown | expected_if_random | excess | excess_lo | excess_hi | verdict |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| gemma3_4b | mc | 2 | 89 | 0.236 | 0.250 | -0.014 | -0.112 | 0.087 | H3a not supported at every N |
| gemma3_4b | mc | 3 | 111 | 0.523 | 0.500 | 0.023 | -0.078 | 0.117 | H3a not supported at every N |
| gemma3_4b | mc | 4 | 117 | 0.744 | 0.750 | -0.006 | -0.086 | 0.071 | H3a not supported at every N |
| gemma3_4b | open | 2 | 7 | 0.286 | 0.250 | 0.036 | -0.250 | 0.321 | descriptive only (open mode) |
| gemma3_4b | open | 3 | 8 | 0.375 | 0.500 | -0.125 | -0.375 | 0.250 | descriptive only (open mode) |
| gemma3_4b | open | 4 | 10 | 0.800 | 0.750 | 0.050 | -0.250 | 0.250 | descriptive only (open mode) |
| gemma4 | mc | 2 | 42 | 0.190 | 0.250 | -0.060 | -0.199 | 0.106 | H3a not supported at every N |
| gemma4 | mc | 3 | 48 | 0.521 | 0.500 | 0.021 | -0.160 | 0.189 | H3a not supported at every N |
| gemma4 | mc | 4 | 44 | 0.636 | 0.750 | -0.114 | -0.298 | 0.075 | H3a not supported at every N |
| gemma4 | open | 2 | 10 | 0.200 | 0.250 | -0.050 | -0.250 | 0.250 | descriptive only (open mode) |
| gemma4 | open | 3 | 8 | 0.500 | 0.500 | 0.000 | -0.375 | 0.375 | descriptive only (open mode) |
| gemma4 | open | 4 | 8 | 0.750 | 0.750 | 0.000 | -0.375 | 0.250 | descriptive only (open mode) |
| granite4v | mc | 2 | 109 | 0.303 | 0.250 | 0.053 | -0.041 | 0.146 | H3a not supported at every N |
| granite4v | mc | 3 | 136 | 0.618 | 0.500 | 0.118 | 0.034 | 0.199 | H3a not supported at every N |
| granite4v | mc | 4 | 141 | 0.787 | 0.750 | 0.037 | -0.041 | 0.108 | H3a not supported at every N |
| granite4v | open | 2 | 3 | 0.000 | 0.250 | -0.250 | -0.250 | -0.250 | descriptive only (open mode) |
| granite4v | open | 3 | 5 | 0.400 | 0.500 | -0.100 | -0.500 | 0.300 | descriptive only (open mode) |
| granite4v | open | 4 | 6 | 0.667 | 0.750 | -0.083 | -0.417 | 0.250 | descriptive only (open mode) |
| lfm25v | mc | 2 | 109 | 0.431 | 0.250 | 0.181 | 0.086 | 0.270 | H3a supported (all N) |
| lfm25v | mc | 3 | 133 | 0.639 | 0.500 | 0.139 | 0.054 | 0.227 | H3a supported (all N) |
| lfm25v | mc | 4 | 143 | 0.839 | 0.750 | 0.089 | 0.025 | 0.146 | H3a supported (all N) |
| lfm25v | open | 2 | 3 | 0.667 | 0.250 | 0.417 | -0.250 | 0.750 | descriptive only (open mode) |
| lfm25v | open | 3 | 2 | 0.500 | 0.500 | 0.000 | -0.500 | 0.500 | descriptive only (open mode) |
| lfm25v | open | 4 | 4 | 0.750 | 0.750 | 0.000 | -0.500 | 0.250 | descriptive only (open mode) |
| qwen25vl | mc | 2 | 51 | 0.176 | 0.250 | -0.074 | -0.189 | 0.056 | H3a not supported at every N |
| qwen25vl | mc | 3 | 50 | 0.460 | 0.500 | -0.040 | -0.173 | 0.100 | H3a not supported at every N |
| qwen25vl | mc | 4 | 47 | 0.617 | 0.750 | -0.133 | -0.262 | 0.000 | H3a not supported at every N |
| qwen25vl | open | 2 | 5 | 0.200 | 0.250 | -0.050 | -0.250 | 0.350 | descriptive only (open mode) |
| qwen25vl | open | 3 | 3 | 0.333 | 0.500 | -0.167 | -0.500 | 0.500 | descriptive only (open mode) |
| qwen25vl | open | 4 | 2 | 0.500 | 0.750 | -0.250 | -0.750 | 0.250 | descriptive only (open mode) |
| qwen3vl | mc | 2 | 46 | 0.217 | 0.250 | -0.033 | -0.141 | 0.098 | H3a not supported at every N |
| qwen3vl | mc | 3 | 50 | 0.520 | 0.500 | 0.020 | -0.135 | 0.179 | H3a not supported at every N |
| qwen3vl | mc | 4 | 56 | 0.696 | 0.750 | -0.054 | -0.203 | 0.089 | H3a not supported at every N |
| qwen3vl | open | 2 | 8 | 0.125 | 0.250 | -0.125 | -0.250 | 0.125 | descriptive only (open mode) |
| qwen3vl | open | 3 | 8 | 0.500 | 0.500 | 0.000 | -0.500 | 0.375 | descriptive only (open mode) |
| qwen3vl | open | 4 | 8 | 0.750 | 0.750 | 0.000 | -0.321 | 0.250 | descriptive only (open mode) |


## near_vs_far

| model | mode | N | metric | near | far | far_minus_near | lo | hi | targets |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| gemma3_4b | mc | 2 | joint_acc | 0.500 | 0.605 | 0.105 | 0.020 | 0.191 | 152 |
| gemma3_4b | mc | 2 | mis_binding_rate | 0.095 | 0.053 | -0.043 | -0.089 | 0.003 | 152 |
| gemma3_4b | mc | 5 | joint_acc | 0.362 | 0.507 | 0.145 | 0.059 | 0.230 | 152 |
| gemma3_4b | mc | 5 | mis_binding_rate | 0.457 | 0.329 | -0.128 | -0.194 | -0.059 | 152 |
| gemma3_4b | open | 2 | joint_acc | 0.171 | 0.164 | -0.007 | -0.026 | 0.013 | 152 |
| gemma3_4b | open | 2 | mis_binding_rate | 0.013 | 0.003 | -0.010 | -0.023 | 0.000 | 152 |
| gemma3_4b | open | 5 | joint_acc | 0.164 | 0.151 | -0.013 | -0.059 | 0.033 | 152 |
| gemma3_4b | open | 5 | mis_binding_rate | 0.069 | 0.036 | -0.033 | -0.069 | 0.003 | 152 |
| gemma4 | mc | 2 | joint_acc | 0.783 | 0.862 | 0.079 | 0.000 | 0.158 | 152 |
| gemma4 | mc | 2 | mis_binding_rate | 0.033 | 0.003 | -0.030 | -0.053 | -0.007 | 152 |
| gemma4 | mc | 5 | joint_acc | 0.743 | 0.855 | 0.112 | 0.053 | 0.178 | 152 |
| gemma4 | mc | 5 | mis_binding_rate | 0.207 | 0.112 | -0.095 | -0.148 | -0.043 | 152 |
| gemma4 | open | 2 | joint_acc | 0.164 | 0.171 | 0.007 | 0.000 | 0.020 | 152 |
| gemma4 | open | 2 | mis_binding_rate | 0.026 | 0.013 | -0.013 | -0.036 | 0.013 | 152 |
| gemma4 | open | 5 | joint_acc | 0.151 | 0.158 | 0.007 | -0.013 | 0.033 | 152 |
| gemma4 | open | 5 | mis_binding_rate | 0.072 | 0.013 | -0.059 | -0.092 | -0.030 | 152 |
| granite4v | mc | 2 | joint_acc | 0.421 | 0.526 | 0.105 | 0.020 | 0.197 | 152 |
| granite4v | mc | 2 | mis_binding_rate | 0.135 | 0.132 | -0.003 | -0.062 | 0.056 | 152 |
| granite4v | mc | 5 | joint_acc | 0.263 | 0.375 | 0.112 | 0.026 | 0.191 | 152 |
| granite4v | mc | 5 | mis_binding_rate | 0.487 | 0.438 | -0.049 | -0.125 | 0.023 | 152 |
| granite4v | open | 2 | joint_acc | 0.046 | 0.059 | 0.013 | -0.007 | 0.039 | 152 |
| granite4v | open | 2 | mis_binding_rate | 0.003 | 0.003 | 0.000 | -0.010 | 0.010 | 152 |
| granite4v | open | 5 | joint_acc | 0.059 | 0.059 | 0.000 | -0.020 | 0.020 | 152 |
| granite4v | open | 5 | mis_binding_rate | 0.026 | 0.007 | -0.020 | -0.039 | -0.003 | 152 |
| lfm25v | mc | 2 | joint_acc | 0.434 | 0.553 | 0.118 | 0.039 | 0.197 | 152 |
| lfm25v | mc | 2 | mis_binding_rate | 0.128 | 0.105 | -0.023 | -0.079 | 0.033 | 152 |
| lfm25v | mc | 5 | joint_acc | 0.224 | 0.355 | 0.132 | 0.053 | 0.211 | 152 |
| lfm25v | mc | 5 | mis_binding_rate | 0.576 | 0.500 | -0.076 | -0.141 | -0.007 | 152 |
| lfm25v | open | 2 | joint_acc | 0.125 | 0.118 | -0.007 | -0.033 | 0.013 | 152 |
| lfm25v | open | 2 | mis_binding_rate | 0.016 | 0.003 | -0.013 | -0.026 | -0.003 | 152 |
| lfm25v | open | 5 | joint_acc | 0.105 | 0.092 | -0.013 | -0.039 | 0.013 | 152 |
| lfm25v | open | 5 | mis_binding_rate | 0.039 | 0.000 | -0.039 | -0.066 | -0.020 | 152 |
| qwen25vl | mc | 2 | joint_acc | 0.658 | 0.737 | 0.079 | 0.007 | 0.151 | 152 |
| qwen25vl | mc | 2 | mis_binding_rate | 0.039 | 0.026 | -0.013 | -0.046 | 0.020 | 152 |
| qwen25vl | mc | 5 | joint_acc | 0.651 | 0.750 | 0.099 | 0.026 | 0.171 | 152 |
| qwen25vl | mc | 5 | mis_binding_rate | 0.224 | 0.155 | -0.069 | -0.118 | -0.020 | 152 |
| qwen25vl | open | 2 | joint_acc | 0.296 | 0.296 | 0.000 | -0.020 | 0.020 | 152 |
| qwen25vl | open | 2 | mis_binding_rate | 0.010 | 0.000 | -0.010 | -0.023 | 0.000 | 152 |
| qwen25vl | open | 5 | joint_acc | 0.296 | 0.289 | -0.007 | -0.033 | 0.013 | 152 |
| qwen25vl | open | 5 | mis_binding_rate | 0.039 | 0.007 | -0.033 | -0.059 | -0.010 | 152 |
| qwen3vl | mc | 2 | joint_acc | 0.776 | 0.849 | 0.072 | 0.000 | 0.145 | 152 |
| qwen3vl | mc | 2 | mis_binding_rate | 0.036 | 0.033 | -0.003 | -0.030 | 0.023 | 152 |
| qwen3vl | mc | 5 | joint_acc | 0.783 | 0.882 | 0.099 | 0.033 | 0.164 | 152 |
| qwen3vl | mc | 5 | mis_binding_rate | 0.168 | 0.082 | -0.086 | -0.135 | -0.039 | 152 |
| qwen3vl | open | 2 | joint_acc | 0.178 | 0.178 | 0.000 | -0.020 | 0.020 | 152 |
| qwen3vl | open | 2 | mis_binding_rate | 0.023 | 0.003 | -0.020 | -0.039 | -0.003 | 152 |
| qwen3vl | open | 5 | joint_acc | 0.191 | 0.184 | -0.007 | -0.033 | 0.013 | 152 |
| qwen3vl | open | 5 | mis_binding_rate | 0.049 | 0.013 | -0.036 | -0.066 | -0.010 | 152 |


## h3_near_regression

| model | mode | near_coef | near_p | odds_ratio | clip_adjusted | near_p_holm | verdict |
| --- | --- | --- | --- | --- | --- | --- | --- |
| gemma3_4b | mc | -0.461 | 0.001 | 0.631 | True | 0.015 | H3b supported (near hurts) |
| gemma3_4b | open | 0.136 | 0.175 | 1.146 | True | 0.727 | H3b not supported |
| gemma4 | mc | -0.562 | 0.009 | 0.570 | True | 0.078 | H3b not supported |
| gemma4 | open | 0.007 | 0.904 | 1.007 | True | 1.000 | H3b not supported |
| granite4v | mc | -0.431 | 0.007 | 0.650 | True | 0.070 | H3b not supported |
| granite4v | open | -0.027 | 0.877 | 0.973 | True | 1.000 | H3b not supported |
| lfm25v | mc | -0.506 | 0.001 | 0.603 | True | 0.010 | H3b supported (near hurts) |
| lfm25v | open | 0.178 | 0.061 | 1.195 | True | 0.364 | H3b not supported |
| qwen25vl | mc | -0.369 | 0.024 | 0.692 | True | 0.170 | H3b not supported |
| qwen25vl | open | 0.075 | 0.145 | 1.078 | True | 0.727 | H3b not supported |
| qwen3vl | mc | -0.557 | 0.013 | 0.573 | True | 0.102 | H3b not supported |
| qwen3vl | open | 0.077 | 0.279 | 1.080 | True | 0.838 | H3b not supported |


## illusory_conjunctions

| model | mode | N | wrong_joint | icr_observed | icr_independence_baseline | excess | p_perm | p_holm |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| gemma3_4b | mc | 2 | 69 | 0.159 | 0.200 | -0.041 | 0.946 | 1.000 |
| gemma3_4b | mc | 3 | 88 | 0.420 | 0.436 | -0.015 | 0.708 | 1.000 |
| gemma3_4b | mc | 4 | 91 | 0.571 | 0.651 | -0.080 | 0.996 | 1.000 |
| gemma3_4b | mc | 5 | 453 | 0.870 | 0.939 | -0.069 | 1.000 | 1.000 |
| gemma3_4b | open | 2 | 130 | 0.000 | 0.003 | -0.003 | 1.000 | 1.000 |
| gemma3_4b | open | 3 | 130 | 0.000 | 0.005 | -0.005 | 1.000 | 1.000 |
| gemma3_4b | open | 4 | 131 | 0.000 | 0.012 | -0.012 | 1.000 | 1.000 |
| gemma3_4b | open | 5 | 667 | 0.006 | 0.017 | -0.011 | 0.998 | 1.000 |
| gemma4 | mc | 2 | 28 | 0.143 | 0.178 | -0.035 | 0.920 | 1.000 |
| gemma4 | mc | 3 | 29 | 0.207 | 0.493 | -0.286 | 1.000 | 1.000 |
| gemma4 | mc | 4 | 27 | 0.333 | 0.614 | -0.281 | 1.000 | 1.000 |
| gemma4 | mc | 5 | 159 | 0.497 | 0.979 | -0.482 | 1.000 | 1.000 |
| gemma4 | open | 2 | 135 | 0.000 | 0.003 | -0.003 | 1.000 | 1.000 |
| gemma4 | open | 3 | 133 | 0.000 | 0.003 | -0.003 | 1.000 | 1.000 |
| gemma4 | open | 4 | 134 | 0.000 | 0.007 | -0.007 | 1.000 | 1.000 |
| gemma4 | open | 5 | 672 | 0.003 | 0.012 | -0.009 | 0.998 | 1.000 |
| granite4v | mc | 2 | 81 | 0.160 | 0.210 | -0.049 | 0.972 | 1.000 |
| granite4v | mc | 3 | 99 | 0.303 | 0.441 | -0.138 | 1.000 | 1.000 |
| granite4v | mc | 4 | 109 | 0.532 | 0.586 | -0.053 | 0.965 | 1.000 |
| granite4v | mc | 5 | 544 | 0.643 | 0.819 | -0.176 | 1.000 | 1.000 |
| granite4v | open | 2 | 149 | 0.000 | 0.000 | 0.000 | 1.000 | 1.000 |
| granite4v | open | 3 | 152 | 0.007 | 0.000 | 0.006 | 0.002 | 0.094 |
| granite4v | open | 4 | 151 | 0.007 | 0.004 | 0.003 | 0.099 | 1.000 |
| granite4v | open | 5 | 749 | 0.001 | 0.006 | -0.005 | 0.959 | 1.000 |
| lfm25v | mc | 2 | 81 | 0.296 | 0.350 | -0.054 | 0.974 | 1.000 |
| lfm25v | mc | 3 | 99 | 0.505 | 0.534 | -0.029 | 0.827 | 1.000 |
| lfm25v | mc | 4 | 105 | 0.705 | 0.720 | -0.015 | 0.723 | 1.000 |
| lfm25v | mc | 5 | 548 | 0.821 | 0.912 | -0.091 | 1.000 | 1.000 |
| lfm25v | open | 2 | 143 | 0.000 | 0.002 | -0.002 | 1.000 | 1.000 |
| lfm25v | open | 3 | 139 | 0.000 | 0.001 | -0.001 | 1.000 | 1.000 |
| lfm25v | open | 4 | 142 | 0.000 | 0.005 | -0.005 | 1.000 | 1.000 |
| lfm25v | open | 5 | 719 | 0.004 | 0.005 | -0.001 | 0.585 | 1.000 |
| qwen25vl | mc | 2 | 41 | 0.098 | 0.163 | -0.065 | 0.991 | 1.000 |
| qwen25vl | mc | 3 | 42 | 0.405 | 0.439 | -0.034 | 0.898 | 1.000 |
| qwen25vl | mc | 4 | 40 | 0.550 | 0.591 | -0.041 | 0.938 | 1.000 |
| qwen25vl | mc | 5 | 198 | 0.955 | 0.983 | -0.029 | 1.000 | 1.000 |
| qwen25vl | open | 2 | 111 | 0.000 | 0.003 | -0.003 | 1.000 | 1.000 |
| qwen25vl | open | 3 | 113 | 0.009 | 0.002 | 0.007 | 0.001 | 0.048 |
| qwen25vl | open | 4 | 115 | 0.000 | 0.002 | -0.002 | 1.000 | 1.000 |
| qwen25vl | open | 5 | 572 | 0.002 | 0.009 | -0.007 | 0.996 | 1.000 |
| qwen3vl | mc | 2 | 31 | 0.129 | 0.199 | -0.070 | 0.990 | 1.000 |
| qwen3vl | mc | 3 | 34 | 0.382 | 0.491 | -0.109 | 0.998 | 1.000 |
| qwen3vl | mc | 4 | 36 | 0.472 | 0.663 | -0.191 | 1.000 | 1.000 |
| qwen3vl | mc | 5 | 154 | 0.734 | 0.981 | -0.247 | 1.000 | 1.000 |
| qwen3vl | open | 2 | 129 | 0.000 | 0.002 | -0.002 | 1.000 | 1.000 |
| qwen3vl | open | 3 | 129 | 0.000 | 0.008 | -0.008 | 1.000 | 1.000 |
| qwen3vl | open | 4 | 132 | 0.000 | 0.011 | -0.011 | 1.000 | 1.000 |
| qwen3vl | open | 5 | 648 | 0.002 | 0.017 | -0.015 | 1.000 | 1.000 |


## by_popularity_tier

| model | mode | tier | acc_N1 | acc_N5 | prior_drift_share |
| --- | --- | --- | --- | --- | --- |
| gemma3_4b | mc | high | 0.654 | 0.604 | 0.151 |
| gemma3_4b | mc | low | 0.564 | 0.349 | 0.170 |
| gemma3_4b | mc | mid | 0.472 | 0.355 | 0.167 |
| gemma3_4b | open | high | 0.346 | 0.373 | 0.867 |
| gemma3_4b | open | low | 0.055 | 0.055 | 0.925 |
| gemma3_4b | open | mid | 0.057 | 0.079 | 0.915 |
| gemma4 | mc | high | 0.942 | 0.892 | 0.113 |
| gemma4 | mc | low | 0.836 | 0.767 | 0.250 |
| gemma4 | mc | mid | 0.792 | 0.747 | 0.166 |
| gemma4 | open | high | 0.462 | 0.408 | 0.766 |
| gemma4 | open | low | 0.036 | 0.036 | 0.720 |
| gemma4 | open | mid | 0.057 | 0.045 | 0.683 |
| granite4v | mc | high | 0.692 | 0.496 | 0.117 |
| granite4v | mc | low | 0.436 | 0.211 | 0.146 |
| granite4v | mc | mid | 0.509 | 0.260 | 0.113 |
| granite4v | open | high | 0.115 | 0.150 | 0.591 |
| granite4v | open | low | 0.000 | 0.025 | 0.585 |
| granite4v | open | mid | 0.019 | 0.019 | 0.535 |
| lfm25v | mc | high | 0.673 | 0.465 | 0.092 |
| lfm25v | mc | low | 0.418 | 0.207 | 0.124 |
| lfm25v | mc | mid | 0.585 | 0.279 | 0.117 |
| lfm25v | open | high | 0.327 | 0.265 | 0.623 |
| lfm25v | open | low | 0.018 | 0.011 | 0.671 |
| lfm25v | open | mid | 0.057 | 0.034 | 0.675 |
| qwen25vl | mc | high | 0.769 | 0.808 | 0.175 |
| qwen25vl | mc | low | 0.673 | 0.691 | 0.241 |
| qwen25vl | mc | mid | 0.642 | 0.762 | 0.237 |
| qwen25vl | open | high | 0.538 | 0.508 | 0.796 |
| qwen25vl | open | low | 0.127 | 0.116 | 0.694 |
| qwen25vl | open | mid | 0.245 | 0.242 | 0.566 |
| qwen3vl | mc | high | 0.904 | 0.908 | 0.129 |
| qwen3vl | mc | low | 0.818 | 0.767 | 0.284 |
| qwen3vl | mc | mid | 0.774 | 0.751 | 0.166 |
| qwen3vl | open | high | 0.385 | 0.423 | 0.824 |
| qwen3vl | open | low | 0.091 | 0.084 | 0.864 |
| qwen3vl | open | mid | 0.094 | 0.072 | 0.831 |


## paraphrase_check

| model | mode | variant | 1 | 2 | 3 | 4 | 5 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| gemma3_4b | mc | P1 | 0.625 | 0.643 | 0.679 | 0.482 | 0.536 |
| gemma3_4b | mc | P2 | 0.625 | 0.643 | 0.643 | 0.518 | 0.500 |
| gemma3_4b | mc | P3 | 0.607 | 0.571 | 0.661 | 0.482 | 0.464 |
| gemma3_4b | open | P1 | 0.304 | 0.393 | 0.375 | 0.375 | 0.393 |
| gemma3_4b | open | P2 | 0.304 | 0.357 | 0.375 | 0.375 | 0.393 |
| gemma3_4b | open | P3 | 0.339 | 0.375 | 0.375 | 0.357 | 0.393 |
| gemma4 | mc | P1 | 0.857 | 0.839 | 0.857 | 0.857 | 0.821 |
| gemma4 | mc | P2 | 0.839 | 0.821 | 0.857 | 0.821 | 0.839 |
| gemma4 | mc | P3 | 0.857 | 0.839 | 0.857 | 0.821 | 0.821 |
| gemma4 | open | P1 | 0.375 | 0.339 | 0.357 | 0.321 | 0.357 |
| gemma4 | open | P2 | 0.375 | 0.339 | 0.339 | 0.321 | 0.357 |
| gemma4 | open | P3 | 0.375 | 0.321 | 0.321 | 0.321 | 0.339 |
| granite4v | mc | P1 | 0.607 | 0.536 | 0.518 | 0.375 | 0.357 |
| granite4v | mc | P2 | 0.589 | 0.571 | 0.500 | 0.375 | 0.357 |
| granite4v | mc | P3 | 0.607 | 0.554 | 0.500 | 0.393 | 0.321 |
| granite4v | open | P1 | 0.107 | 0.125 | 0.143 | 0.125 | 0.161 |
| granite4v | open | P2 | 0.143 | 0.071 | 0.143 | 0.107 | 0.143 |
| granite4v | open | P3 | 0.089 | 0.089 | 0.107 | 0.107 | 0.143 |
| lfm25v | mc | P1 | 0.643 | 0.589 | 0.446 | 0.393 | 0.411 |
| lfm25v | mc | P2 | 0.661 | 0.571 | 0.446 | 0.411 | 0.393 |
| lfm25v | mc | P3 | 0.661 | 0.571 | 0.464 | 0.411 | 0.375 |
| lfm25v | open | P1 | 0.286 | 0.250 | 0.304 | 0.268 | 0.214 |
| lfm25v | open | P2 | 0.321 | 0.268 | 0.268 | 0.250 | 0.232 |
| lfm25v | open | P3 | 0.268 | 0.214 | 0.214 | 0.232 | 0.214 |
| qwen25vl | mc | P1 | 0.714 | 0.768 | 0.804 | 0.804 | 0.768 |
| qwen25vl | mc | P2 | 0.732 | 0.768 | 0.804 | 0.821 | 0.786 |
| qwen25vl | mc | P3 | 0.750 | 0.768 | 0.804 | 0.821 | 0.768 |
| qwen25vl | open | P1 | 0.446 | 0.446 | 0.446 | 0.429 | 0.429 |
| qwen25vl | open | P2 | 0.429 | 0.429 | 0.429 | 0.429 | 0.429 |
| qwen25vl | open | P3 | 0.393 | 0.446 | 0.429 | 0.429 | 0.411 |
| qwen3vl | mc | P1 | 0.839 | 0.875 | 0.857 | 0.839 | 0.839 |
| qwen3vl | mc | P2 | 0.857 | 0.875 | 0.857 | 0.839 | 0.857 |
| qwen3vl | mc | P3 | 0.857 | 0.893 | 0.875 | 0.821 | 0.857 |
| qwen3vl | open | P1 | 0.304 | 0.286 | 0.304 | 0.286 | 0.321 |
| qwen3vl | open | P2 | 0.321 | 0.304 | 0.304 | 0.304 | 0.321 |
| qwen3vl | open | P3 | 0.268 | 0.304 | 0.339 | 0.321 | 0.357 |


## text_only_leak

| model | mode | trials | item_correct | country_correct |
| --- | --- | --- | --- | --- |
| gemma3_4b | mc | 160 | 0.206 | 0.212 |
| gemma3_4b | open | 160 | 0.000 | 0.050 |
| gemma4 | mc | 160 | 0.000 | 0.000 |
| gemma4 | open | 160 | 0.000 | 0.000 |
| granite4v | mc | 160 | 0.087 | 0.069 |
| granite4v | open | 160 | 0.000 | 0.000 |
| lfm25v | mc | 160 | 0.256 | 0.169 |
| lfm25v | open | 160 | 0.000 | 0.044 |
| qwen25vl | mc | 160 | 0.250 | 0.256 |
| qwen25vl | open | 160 | 0.000 | 0.019 |
| qwen3vl | mc | 160 | 0.244 | 0.237 |
| qwen3vl | open | 160 | 0.000 | 0.000 |


## describe_then_answer

| model | mode | N | targets | p1_acc | p4_acc | rescue | lo | hi | verdict |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| gemma3_4b | mc | 1 | 56 | 0.625 | 0.625 | 0.000 | -0.089 | 0.089 | no clear effect |
| gemma3_4b | mc | 2 | 56 | 0.643 | 0.607 | -0.036 | -0.125 | 0.054 | no clear effect |
| gemma3_4b | mc | 3 | 56 | 0.679 | 0.482 | -0.196 | -0.321 | -0.071 | hurts |
| gemma3_4b | mc | 4 | 56 | 0.482 | 0.304 | -0.179 | -0.339 | -0.018 | hurts |
| gemma3_4b | mc | 5 | 56 | 0.536 | 0.357 | -0.179 | -0.286 | -0.071 | hurts |
| gemma3_4b | mc | all | 56 | 0.593 | 0.475 | -0.118 | -0.186 | -0.054 | hurts |
| gemma3_4b | open | 1 | 56 | 0.304 | 0.321 | 0.018 | -0.071 | 0.107 | no clear effect |
| gemma3_4b | open | 2 | 56 | 0.393 | 0.214 | -0.179 | -0.304 | -0.071 | hurts |
| gemma3_4b | open | 3 | 56 | 0.375 | 0.321 | -0.054 | -0.143 | 0.036 | no clear effect |
| gemma3_4b | open | 4 | 56 | 0.375 | 0.196 | -0.179 | -0.286 | -0.071 | hurts |
| gemma3_4b | open | 5 | 56 | 0.393 | 0.286 | -0.107 | -0.196 | -0.018 | hurts |
| gemma3_4b | open | all | 56 | 0.368 | 0.268 | -0.100 | -0.164 | -0.039 | hurts |
| gemma4 | mc | 1 | 56 | 0.857 | 0.839 | -0.018 | -0.107 | 0.054 | no clear effect |
| gemma4 | mc | 2 | 56 | 0.839 | 0.821 | -0.018 | -0.054 | 0.000 | no clear effect |
| gemma4 | mc | 3 | 56 | 0.857 | 0.821 | -0.036 | -0.089 | 0.000 | no clear effect |
| gemma4 | mc | 4 | 56 | 0.857 | 0.821 | -0.036 | -0.107 | 0.036 | no clear effect |
| gemma4 | mc | 5 | 56 | 0.821 | 0.804 | -0.018 | -0.089 | 0.036 | no clear effect |
| gemma4 | mc | all | 56 | 0.846 | 0.821 | -0.025 | -0.054 | 0.000 | no clear effect |
| gemma4 | open | 1 | 56 | 0.375 | 0.375 | 0.000 | -0.054 | 0.054 | no clear effect |
| gemma4 | open | 2 | 56 | 0.339 | 0.304 | -0.036 | -0.089 | 0.000 | no clear effect |
| gemma4 | open | 3 | 56 | 0.357 | 0.286 | -0.071 | -0.143 | -0.018 | hurts |
| gemma4 | open | 4 | 56 | 0.321 | 0.286 | -0.036 | -0.089 | 0.000 | no clear effect |
| gemma4 | open | 5 | 56 | 0.357 | 0.304 | -0.054 | -0.125 | 0.000 | no clear effect |
| gemma4 | open | all | 56 | 0.350 | 0.311 | -0.039 | -0.086 | 0.000 | no clear effect |
| granite4v | mc | 1 | 56 | 0.607 | 0.643 | 0.036 | -0.018 | 0.107 | no clear effect |
| granite4v | mc | 2 | 56 | 0.536 | 0.446 | -0.089 | -0.214 | 0.018 | no clear effect |
| granite4v | mc | 3 | 56 | 0.518 | 0.429 | -0.089 | -0.196 | 0.000 | no clear effect |
| granite4v | mc | 4 | 56 | 0.375 | 0.268 | -0.107 | -0.214 | 0.000 | no clear effect |
| granite4v | mc | 5 | 56 | 0.357 | 0.196 | -0.161 | -0.268 | -0.071 | hurts |
| granite4v | mc | all | 56 | 0.479 | 0.396 | -0.082 | -0.143 | -0.025 | hurts |
| granite4v | open | 1 | 56 | 0.107 | 0.125 | 0.018 | -0.036 | 0.071 | no clear effect |
| granite4v | open | 2 | 56 | 0.125 | 0.071 | -0.054 | -0.125 | 0.000 | no clear effect |
| granite4v | open | 3 | 56 | 0.143 | 0.161 | 0.018 | -0.054 | 0.089 | no clear effect |
| granite4v | open | 4 | 56 | 0.125 | 0.125 | 0.000 | -0.089 | 0.089 | no clear effect |
| granite4v | open | 5 | 56 | 0.161 | 0.071 | -0.089 | -0.179 | 0.000 | no clear effect |
| granite4v | open | all | 56 | 0.132 | 0.111 | -0.021 | -0.072 | 0.021 | no clear effect |
| lfm25v | mc | 1 | 56 | 0.643 | 0.679 | 0.036 | 0.000 | 0.089 | no clear effect |
| lfm25v | mc | 2 | 56 | 0.589 | 0.554 | -0.036 | -0.107 | 0.036 | no clear effect |
| lfm25v | mc | 3 | 56 | 0.446 | 0.500 | 0.054 | 0.000 | 0.125 | no clear effect |
| lfm25v | mc | 4 | 56 | 0.393 | 0.393 | 0.000 | -0.071 | 0.071 | no clear effect |
| lfm25v | mc | 5 | 56 | 0.411 | 0.357 | -0.054 | -0.125 | 0.000 | no clear effect |
| lfm25v | mc | all | 56 | 0.496 | 0.496 | -0.000 | -0.029 | 0.032 | no clear effect |
| lfm25v | open | 1 | 56 | 0.286 | 0.268 | -0.018 | -0.071 | 0.036 | no clear effect |
| lfm25v | open | 2 | 56 | 0.250 | 0.214 | -0.036 | -0.107 | 0.036 | no clear effect |
| lfm25v | open | 3 | 56 | 0.304 | 0.232 | -0.071 | -0.143 | -0.018 | hurts |
| lfm25v | open | 4 | 56 | 0.268 | 0.232 | -0.036 | -0.107 | 0.036 | no clear effect |
| lfm25v | open | 5 | 56 | 0.214 | 0.250 | 0.036 | 0.000 | 0.089 | no clear effect |
| lfm25v | open | all | 56 | 0.264 | 0.239 | -0.025 | -0.071 | 0.018 | no clear effect |
| qwen25vl | mc | 1 | 56 | 0.714 | 0.696 | -0.018 | -0.125 | 0.089 | no clear effect |
| qwen25vl | mc | 2 | 56 | 0.768 | 0.732 | -0.036 | -0.107 | 0.036 | no clear effect |
| qwen25vl | mc | 3 | 56 | 0.804 | 0.768 | -0.036 | -0.125 | 0.054 | no clear effect |
| qwen25vl | mc | 4 | 56 | 0.804 | 0.696 | -0.107 | -0.214 | 0.000 | no clear effect |
| qwen25vl | mc | 5 | 56 | 0.768 | 0.786 | 0.018 | -0.071 | 0.107 | no clear effect |
| qwen25vl | mc | all | 56 | 0.771 | 0.736 | -0.036 | -0.089 | 0.018 | no clear effect |
| qwen25vl | open | 1 | 56 | 0.446 | 0.429 | -0.018 | -0.071 | 0.036 | no clear effect |
| qwen25vl | open | 2 | 56 | 0.446 | 0.429 | -0.018 | -0.071 | 0.036 | no clear effect |
| qwen25vl | open | 3 | 56 | 0.446 | 0.429 | -0.018 | -0.071 | 0.036 | no clear effect |
| qwen25vl | open | 4 | 56 | 0.429 | 0.411 | -0.018 | -0.089 | 0.036 | no clear effect |
| qwen25vl | open | 5 | 56 | 0.429 | 0.357 | -0.071 | -0.161 | 0.000 | no clear effect |
| qwen25vl | open | all | 56 | 0.439 | 0.411 | -0.029 | -0.086 | 0.029 | no clear effect |
| qwen3vl | mc | 1 | 56 | 0.839 | 0.875 | 0.036 | 0.000 | 0.089 | no clear effect |
| qwen3vl | mc | 2 | 56 | 0.875 | 0.857 | -0.018 | -0.054 | 0.000 | no clear effect |
| qwen3vl | mc | 3 | 56 | 0.857 | 0.857 | 0.000 | 0.000 | 0.000 | no clear effect |
| qwen3vl | mc | 4 | 56 | 0.839 | 0.804 | -0.036 | -0.089 | 0.000 | no clear effect |
| qwen3vl | mc | 5 | 56 | 0.839 | 0.768 | -0.071 | -0.161 | 0.018 | no clear effect |
| qwen3vl | mc | all | 56 | 0.850 | 0.832 | -0.018 | -0.043 | 0.007 | no clear effect |
| qwen3vl | open | 1 | 56 | 0.304 | 0.321 | 0.018 | -0.036 | 0.089 | no clear effect |
| qwen3vl | open | 2 | 56 | 0.286 | 0.286 | 0.000 | -0.071 | 0.071 | no clear effect |
| qwen3vl | open | 3 | 56 | 0.304 | 0.250 | -0.054 | -0.143 | 0.018 | no clear effect |
| qwen3vl | open | 4 | 56 | 0.286 | 0.286 | 0.000 | -0.071 | 0.071 | no clear effect |
| qwen3vl | open | 5 | 56 | 0.321 | 0.268 | -0.054 | -0.125 | 0.000 | no clear effect |
| qwen3vl | open | all | 56 | 0.300 | 0.282 | -0.018 | -0.054 | 0.018 | no clear effect |


## attention_capture

| model | mode | N | mis_binding_fields | share_argmax_is_named | chance | lo | hi | verdict |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| qwen3vl | mc | 5 | 221 | 0.172 | 0.200 | 0.092 | 0.247 | no attentional capture |
| qwen3vl | open | 5 | 46 | 0.174 | 0.200 | 0.000 | 0.205 | no attentional capture |
| gemma4 | mc | 5 | 249 | 0.225 | 0.200 | 0.105 | 0.267 | no attentional capture |
| gemma4 | open | 5 | 42 | 0.214 | 0.200 | 0.050 | 0.400 | no attentional capture |
| granite4v | mc | 5 | 747 | 0.182 | 0.200 | 0.131 | 0.232 | no attentional capture |
| granite4v | open | 5 | 39 | 0.333 | 0.200 | 0.253 | 0.663 | attention follows the named image |

## Judge validation (hand-check)

Random 100-row subsample of `data/judge_log.jsonl` (seed 2026, main-study rows only, saved in
`data/judge_sample_100.jsonl`), adjudicated independently against the judge prompt's rules:
**agreement 95/100**. Disagreements: 4 false accepts (Afoxé≈Shekere, Çeng≈Psaltery,
Changua≈"Fisherman's Soup", "Juchu boot"≈Mexican pointy boot — no documented equivalence) and
1 false reject (Jin deui = sesame balls, exact translation). Errors split both directions, so
the judge does not systematically inflate accuracy. 281/19,364 judge verdicts (1.4%) were
unparsed and not written as overrides; those rows keep their heuristic labels (predominantly
format errors), a conservative direction.
