# Pilot gate report (plan §5) — 2026-10-08

Pilot: 96 trials (90 P0 + 6 LEAK), 192 calls/model, 7 models, on the final data build
(890 images after the 17 `exclude.txt` rejections; pool/target/trial regeneration documented in
`data/audit.txt`). Scoring: heuristic scorer + LLM judge (`judge.py`, google/gemma-4-31B-it,
blind, greedy, logged in `data/judge_log.jsonl`); judge labeled 371 review rows
(71 correct / 300 incorrect).

| Gate (pre-registered, plan §5) | Threshold | Outcome | Verdict |
| --- | --- | --- | --- |
| Format | ≤5% of replies | 5 models 0/192; granite4v 8.3%, smolvlm2 15.1% (MC only) | fixed — see below |
| N=1 | ≥1 model ≥5/6 joint, open | best 4/6 open; MC 5–6/6 for 5 models | **documented fail, proceed** |
| Numbering | hand-read 20 replies | 14/20 named target, **0/20 other-shown**, 6/20 wrong-name attempts at the named image | **pass** |
| Text-only leak | MC ≤3/6; open ≤1/6 | MC all ≤3/6; gemma3_4b open country 2/6 | **pass with note** |
| Repeat | ≥18/20 identical | 20/20 for all 7 | **pass** |

## N=1 open — inspection (plan remedy: "inspect each failure")

Failures concentrate on 4 of 6 pilot targets and are item properties, not pipeline faults:

- **Sheng (img_0619): 0/7 models.** Misidentified as shakuhachi/dizi/erhu/bagpipe/zither.
  Genuine recognition difficulty of the least-documented pilot target (37 sitelinks).
- **Notre-Dame de Chartres (img_0789): 0/7.** All models name a *different* cathedral
  (Notre-Dame de Paris ×2, Reims, Metz, Sens, generic). The item name is intrinsically
  confusable; "Chartres Cathedral" itself resolves correctly via alias when produced.
- **Baklava (img_0094):** one Greece attribution (a genuinely contested origin).
- **Bansuri (img_0544):** "flute"/"bamboo flute" accepted via `item_aliases`; country
  abstained by 3 models.

Evidence the pipeline is sane: same models reach 5–6/6 joint on the same targets in MC mode;
label audit 30/30 (`data/label_audit.txt`); visual audit of all 890 images done pre-pilot;
repeat 20/20. Pilot targets were drawn by the pre-registered rule (top-20 high-tier by
sitelinks, country-distinct, seed 2026) — the post-exclusion redraw put Bansuri ahead of
Sitar for the India slot; Sitar remains in the main pool.

**Decision (2026-10-08, user-approved): document and proceed.** No pilot-target swaps:
redesigning the sanity instrument after seeing pilot data would compromise the
pre-registration; the gate's intent (pipeline works on knowable items) is met by the MC
numbers. Pilot targets are kept out of the main targets by design, so main-study claims do
not depend on pilot-target easiness. The open-mode naming gap is itself reported as a
pilot observation (open naming of culturally-specific items is harder than recognition).

## Format — remedy applied (plan remedy: "tighten the format line")

granite4v answered `Country: Italy` (name instead of letter) on 21 MC trials; smolvlm2
collapsed to one-line `E. India` on 17. The MC instruction in `ch.py:make_parts` was
tightened (explicit "option letters, not the full names" + a two-line example) and both
models were re-piloted with the new text; their overrides were regenerated. The other five
models piloted on the v1 text at 0/192 format errors and were not re-run (prompt diff
recorded here; all main runs use the v2 text).

## Leak — note

gemma3_4b's open leak replies are stereotype guesses (Pho→Vietnam, Sitar→India,
Eiffel Tower→France); 2/6 country hits arise from famous-country priors on 6 trials.
No leak channel exists: neutral image IDs, EXIF-stripped, leak prompts contain zero target
information. MC leak (the more informative check) is ≤3/6 for every model.

Re-pilot outcome (v2 MC text): granite4v MC format errors 16→2; smolvlm2 29→69 of 96 MC replies.

## v3 MC text — 2026-10-08 (supersedes v2 before main runs)

The v2 example line backfired: smolvlm2 (2.2B) parroted the worked example, replying
`Item: C / Country: E` verbatim regardless of the question (69/96 MC format errors plus
silent C/E answer bias). v3 = v1 text plus the single clause "Answer with the option
letters, not the full names", **no example**. Both affected models re-piloted on v3;
outcome below. The main runs use v3 for all models.

**Freeze record (no-git variant).** The operative pre-registration freeze is
`prereg_snapshot/` + `PREREG_MANIFEST.sha256` (checksum manifest of all prompts, data,
trials, scripts, judge state and pilot outputs at freeze time), created after the roster
change below and before any main run; an earlier snapshot from the v3 era was superseded
before any main run. Note for the record: automation created a local-only git commit
(`a679183`, tag `prereg-v1`) earlier the same day, capturing the v2 prompt text that was
superseded before any main run; it was never given a remote, never pushed, and is not the
freeze of record. The v1→v2→v3→v1 prompt history is declared here per plan §6.

v3 outcome — granite4v: 17/96 MC format errors (baselines: v1 granite 16, smol 29; v2 granite 2, smol 69).

v3 outcome — smolvlm2: 91/96 MC format errors (baselines: v1 granite 16, smol 29; v2 granite 2, smol 69).

## Final prompt and roster — 2026-10-08 (supersedes v3)

**Prompt: revert to plan-literal v1.** No variant fixed both small models: v2 traded granite4v's errors
for smolvlm2's example parroting; v3 produced a bare-letter collapse in smolvlm2 (91/96). The
pre-registered text in plan.md §5 is v1, so the main runs use v1 with **zero deviation** for all models.
granite4v's 16/96 MC format errors on v1 stand as a documented limitation of that model.

**Roster: smolvlm2 removed, LFM2.5-VL-3B added.** smolvlm2's MC non-compliance was unresolved across
all three variants (29→69→91 of 96), and MC is half the design, so the model was dropped from the
roster before the freeze and replaced with `LiquidAI/LFM2.5-VL-3B` (key `lfm25v`), which keeps the
small-model slot and adds a fifth architecture family (LFM2 hybrid conv+attention). Smoke test
(2026-10-08): loads on transformers 5.x (`Lfm2VlForConditionalGeneration`), generates the required
two-line format in both modes, joint-correct on pilot N=1 and N=2, and its image token (id 124907) is
discoverable for the attention probe. Main runs had not started at the time of the swap, so no
main-study data is affected. The final 7-model roster: qwen3vl, qwen25vl, gemma4, gemma3_12b,
gemma3_4b, granite4v, lfm25v.

## lfm25v pilot — 2026-10-08 (final roster, v1 text)

Full pilot of the replacement model on the final v1 text (192 calls + 20 repeats; LLM judge
applied, 53 review rows labeled, 17 rescued as correct):

| Gate | Threshold | lfm25v outcome | Verdict |
| --- | --- | --- | --- |
| Format | ≤5% of replies | **0/192** (open 0, MC 0) | **pass** |
| N=1 | ≥1 model ≥5/6 joint, open | open joint 3/6; MC 5/6 — same documented fail as the rest of the roster | **documented fail, proceed** |
| Text-only leak | MC ≤3/6; open ≤1/6 | MC item 3/6, country 3/6; open country 2/6 (stereotype priors, same note as gemma3_4b) | **pass with note** |
| Repeat | ≥18/20 identical | 20/20 | **pass** |

Open error profile at N≥2: mis_binding 0, prior_drift 26, abstain 41 (the 3B model abstains
heavily in open mode). MC shows the binding phenomenon the benchmark measures: 16 mis-bindings
and 12 illusory conjunctions among 18 wrong joint answers. lfm25v joins the main runs.

## gemma3_12b excluded from main runs — 2026-10-08 (post-first-freeze, pre-results)

After the first freeze (14:58:52Z) and after qwen3vl's main run had started, but **before
gemma3_12b's own main run started and before any main results were scored or analyzed**, the
roster for the main runs was cut to 6 models: qwen3vl, qwen25vl, gemma4, gemma3_4b, granite4v,
lfm25v. gemma3_12b's pilot data is retained in `pilot_out/`; the exclusion is a roster decision
(redundancy with gemma4 at the same size class, and it reduces the judge's gemma-family overlap
to 2 of 6 evaluated models), not driven by any main-study data — none exists for this model.
The freeze was regenerated after this change (`prereg_snapshot/` + `PREREG_MANIFEST.sha256`
supersede the 14:58:52Z versions, which are declared here per plan §6).

## Post-freeze changes log — 2026-10-09

Changes after freeze v2 (2026-10-08T15:27:50Z), none of which touch prompts, data, trials or
targets:

1. **`run_models.py` attention-capture fix.** gemma4's first attention run crashed at trial 0
   (its sliding-window layers return a 1024-wide attention row vs. full-length global layers;
   `torch.stack` rejected the mixed shapes) and the pipeline shell did not abort (bash `set -e`
   does not fire inside a `for` loop that is part of an `&&` list), so `attn_gemma4.jsonl` was
   empty in the first analysis. `generate_attn` now left-pads sliding-window rows to each
   generation step's source length; the probe was rerun (1,600 rows) and `analyze.py` refreshed.
   qwen3vl/granite4v attention data are unaffected (single-length layers).
2. **Main-study judging** ran after the freeze by design: `judge_overrides.csv` grew to 19,083
   rows (19,364 verdicts logged in `data/judge_log.jsonl`, 281 unparsed/not applied).
3. **Added audit/figure scripts** `verify_results.py` (independent recompute of every headline
   table from raw/scored data — all checks PASS) and `make_figures.py` (`results/figures/`),
   plus `data/judge_sample_100.jsonl` (judge hand-check subsample, agreement 95/100, reported
   in `results/summary.md`).
